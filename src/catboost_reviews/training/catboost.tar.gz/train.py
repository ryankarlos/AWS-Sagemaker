#!/usr/bin/python3

from __future__ import print_function
import pandas as pd 
import os
import sys
import numpy as np
import argparse
import sagemaker
import logging
# Import the mean squared error (MSE) function from sklearn and alias it as 'mse' 
from sklearn.metrics import mean_squared_error as mse 
  
# CatBoost Regression Model 
from catboost import CatBoostRegressor 

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def train(args):
    model_dir = args.model_dir
    model_name = args.model_name

    training_path = os.path.join(args.train_dir , "train.csv")
    validation_path = os.path.join(args.test_dir,  "val.csv")
    train = pd.read_csv(training_path)
    val = pd.read_csv(validation_path)
    X_train = train[1::]
    Y_train = train[0]
    X_val = val[1::]
    Y_val = val[0]

    # Initialize the CatBoostRegressor with RMSE as the loss function 
    model = CatBoostRegressor(loss_function='RMSE') 
    # Fit the model on the training data with verbose logging every 100 iterations 
    model.fit(X_train, Y_train, verbose=100) 

    logger.info('validating model')
    rmse = np.sqrt(mse(Y_val, model.predict(X_val)))
    logger.info("Validation RMSE: ", rmse)
    path = os.path.join(model_dir, model_name)
    logging.info('saving to {}'.format(path))
    model.save_model(path)
    
def get_parser():
    parser = argparse.ArgumentParser(
        description="Script to build Q2X model."
    )

    # sample code to get a hyperparam
    parser.add_argument("--model_dir",
                        help="model_dir",
                        type=str,
                        default=os.environ.get('SM_MODEL_DIR', "model"))
    parser.add_argument('--model-name', type=str, default='catboost_model.dump')
    parser.add_argument('--train_dir', type=str, default=os.environ.get('SM_CHANNEL_TRAIN', "data/output"))
    parser.add_argument('--test_dir', type=str, default=os.environ.get('SM_CHANNEL_TEST',  "data/output"))
    parser.add_argument('--remote_training', type=bool, default=True)
    
    

    return parser


if __name__ == "__main__":
    args = get_parser().parse_args()
    train(args)
    sys.exit(0)